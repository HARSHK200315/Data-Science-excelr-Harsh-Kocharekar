import streamlit as st
import pandas as pd
import joblib
import numpy as np

# Load trained model and scaler
model = joblib.load('logistic_model.pkl')
scaler = joblib.load('scaler.pkl')

st.title("Titanic Survival Prediction App")

st.write("""
### Enter Passenger Details to Predict Survival
""")

# User Inputs
pclass = st.selectbox("Passenger Class (1 = 1st, 3 = 3rd)", [1, 2, 3])
sex = st.selectbox("Sex", ["Male", "Female"])
age = st.slider("Age", 0, 100, 25)
sibsp = st.number_input("Siblings/Spouses Aboard", 0, 8, 0)
parch = st.number_input("Parents/Children Aboard", 0, 6, 0)
fare = st.number_input("Fare", 0.0, 600.0, 32.0)
embarked = st.selectbox("Port of Embarkation", ["Southampton", "Cherbourg", "Queenstown"])

# Button to Predict
if st.button("Predict"):
    # Preprocess inputs to match model features
    sex_encoded = 1 if sex == "Female" else 0
    embarked_Q = 1 if embarked == "Queenstown" else 0
    embarked_S = 1 if embarked == "Southampton" else 0
    
    # Create input array
    # Order must match training columns: Pclass, Sex, Age, SibSp, Parch, Fare, Embarked_Q, Embarked_S
    features = np.array([[pclass, sex_encoded, age, sibsp, parch, fare, embarked_Q, embarked_S]])
    
    # Scale features
    features_scaled = scaler.transform(features)
    
    # Predict
    prediction = model.predict(features_scaled)
    probability = model.predict_proba(features_scaled)[0][1]
    
    if prediction[0] == 1:
        st.success(f"Passenger Survived! (Probability: {probability:.2f})")
    else:
        st.error(f"Passenger Did Not Survive. (Probability: {probability:.2f})")